﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Exception_3
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] args1 = input.Split(",").ToArray();
            List<Card> cards = new List<Card>();
            foreach (var kvp in args1) 
            {
                string[] kvpArgs = kvp.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();
                try
                {
                    Card currCard = new Card(kvpArgs[0], kvpArgs[1]);
                    cards.Add(currCard);
                }
                catch (ArgumentException)
                {

                    Console.WriteLine("Invalid card!"); 
                }
                
                
                
            }
            Console.WriteLine(String.Join(" ",cards));
        }
    }
}
